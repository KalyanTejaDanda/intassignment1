# NgRx data table with sort

Live: [https://ngrx-data-table-with-sort.netlify.app](https://ngrx-data-table-with-sort.netlify.app)
