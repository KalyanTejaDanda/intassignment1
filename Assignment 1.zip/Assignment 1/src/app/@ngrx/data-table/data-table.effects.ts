import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';

@Injectable()
export class DataTableEffects {
  constructor(private actions$: Actions) {}

}
