import { Action, createReducer, on } from '@ngrx/store';
import * as DataTableActions from './data-table.actions';
import { DataTableState, User } from 'src/app/models/data-table';


export const INITIAL_STATE: DataTableState = {
  tableData: [],
  sortDirection: '',
  sortKey: '',
};

export const dataTableFeatureKey = 'dataTable';


export const dataTableReducer = createReducer(
  INITIAL_STATE,
  on(DataTableActions.setData, (state, { data }) => {
    return {
      ...state,
      tableData: data
    };
  }),

  on(DataTableActions.setSortKey, (state, { sortKey }) => {
    sortKey = sortKey?.toLowerCase();

    let sortDirection;
    if (sortKey !== state.sortKey) {
      sortDirection = 'asc';
    } else {
      sortDirection = setSortDirection(state.sortDirection);
    }
    return {
      ...state,
      sortKey,
      sortDirection
    };
  }),

  on(DataTableActions.updateData, (state, { data }) => {
    let updatedData: User[] = []
    // console.log(updatedData)
    // updatedData.map((user) => {
    //   user = user.id === data.id ? data : user;
    // })
    console.log(data)
    state.tableData.forEach((user) => {
      if (user.id === data.id) {
        updatedData.push(data)
        console.log("teste" + data.name)
      } else updatedData.push(user)
    })
    // state.tableData.map((user) => { if (user.id === data.id) { user = data } })
    let newState = { ...state, tableData: updatedData }
    return newState
  }),
);

export function DataTableReducer(state: DataTableState, action: Action) {
  return dataTableReducer(state, action);
}

// Utils
export function setSortDirection(sortDirection: string): string {
  switch (sortDirection) {
    case 'asc':
      return 'desc';
    case 'desc':
      return '';
    case '':
      return 'asc';
    default:
      return '';
  }
}