import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs';
import { DataTableState, HeaderRowItem, User } from 'src/app/models/data-table';

// NgRx
import { Store } from '@ngrx/store';
import * as dataTableActions from 'src/app/@ngrx/data-table/data-table.actions';
import * as dataTableSelectors from 'src/app/@ngrx/data-table/data-table.selectors';
import { Router } from '@angular/router';
import { EDIT_USER } from 'src/app/app-routing.module';
import { DataService } from 'src/app/services/data.service';
import { first, map } from 'rxjs/operators';

@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss'],
})
export class DataTableComponent implements OnInit {
data!: any[];
headerRow = [
  { displayName: 'ID', key: 'id', hasSort: false },
  { displayName: 'Name', key: 'name', hasSort: true },
  { displayName: 'Username', key: 'username', hasSort: false },
  { displayName: 'Email', key: 'email', hasSort: false },
  { displayName: 'Address', key: 'address', hasSort: false },
  { displayName: 'Action', key: 'action', hasSort: false },

];

  public sortDirection$!: Observable<string>;
  public sortKey$!: Observable<string>;
  public tableData$!: Observable<any>;

  constructor(private store: Store<DataTableState>,
    private readonly router: Router) {}

  ngOnInit(): void {
   
    // SELECTORS
    this.tableData$ = this.store.select(dataTableSelectors.selectSortedData);
    this.sortKey$ = this.store.select(dataTableSelectors.selectSortKey);
    this.sortDirection$ = this.store.select(dataTableSelectors.selectSortDirection);
  }

  ngOnDestroy(): void {
    this.store.dispatch(dataTableActions.resetDataTableStore());
  }

  public onSort(headerItem: HeaderRowItem): void {
    if (!headerItem.hasSort) {
      return;
    }
    const sortKey = headerItem.key;
    this.store.dispatch(dataTableActions.setSortKey({ sortKey: sortKey }));
  }

  public onEditUser(user:User){
this.router.navigate([EDIT_USER,user.id])
  }
}
