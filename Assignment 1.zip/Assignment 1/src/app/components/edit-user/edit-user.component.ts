import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { DataTableState, User } from 'src/app/models/data-table';
import * as dataTableSelectors from 'src/app/@ngrx/data-table/data-table.selectors';
import { map } from 'rxjs/operators';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import * as dataTableActions from 'src/app/@ngrx/data-table/data-table.actions';
interface ChangedValue {
  field: string;
  previousValue: string;
  modifiedValue: string
}
const REQUIRED_FIELD_MSG = 'This field is required';
@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.scss']
})
export class EditUserComponent implements OnInit {
  userId!: number;
  public selectedUser: User = {} as User;
  public updatedUser: User = {} as User;
  changesList: ChangedValue[] = []
  form!: FormGroup;
  isSave!: boolean
  headerRow = [
    { displayName: 'Field' },
    { displayName: 'Previous Values' },
    { displayName: 'Modified value' }

  ];

  public userData$!: Observable<any>;
  constructor(private activatedRoute: ActivatedRoute,
    private store: Store<DataTableState>,
    private fb: FormBuilder,
    private readonly router: Router) { }

  ngOnInit(): void {
    this.userId = this.activatedRoute.snapshot.params.id
    this.userData$ = this.store.select(dataTableSelectors.selectDataTableState);
    this.userData$.pipe(map((data: DataTableState) => {
      if (data?.tableData.length) {
        this.selectedUser = data?.tableData.filter((user) => {
          if (user.id.toString() === this.userId.toString()) {
            this.updatedUser = { ...user, address: { ...user.address } }
            return true
          }
          return false
        })[0]
        this.rebuildForm();

      }
    })).subscribe();
    this.form = this.createForm();
    this.onFieldValueChange()

  }

  private onFieldValueChange() {
    this.form.controls.name.valueChanges.subscribe(() => {
      this.updatedUser.name = this.name?.value
      if (this.selectedUser.name != this.updatedUser.name) {
        this.setChangedList('name', this.selectedUser.name, this.updatedUser.name)
      }
    })

    this.form.controls.username.valueChanges.subscribe(() => {
      this.updatedUser.username = this.username?.value
      if (this.selectedUser.username != this.updatedUser.username) {
        this.setChangedList('username', this.selectedUser.username, this.updatedUser.username)
      }
    })

    this.form.controls.email.valueChanges.subscribe(() => {
      this.updatedUser.email = this.email?.value
      if (this.selectedUser.email != this.updatedUser.email) {
        this.setChangedList('email', this.selectedUser.email, this.updatedUser.email)
      }
    })

    this.form.controls.unitNo.valueChanges.subscribe(() => {
      this.updatedUser.address.suite = this.unitNo?.value
      if (this.selectedUser.address.suite != this.updatedUser.address.suite) {
        this.setChangedList('Unit no', this.selectedUser.address.suite, this.updatedUser.address.suite)
      }
    })

    this.form.controls.street.valueChanges.subscribe(() => {
      this.updatedUser.address.street = this.street?.value
      if (this.selectedUser.address.street != this.updatedUser.address.street) {
        this.setChangedList('street', this.selectedUser.address.street, this.updatedUser.address.street)
      }
    })

    this.form.controls.city.valueChanges.subscribe(() => {
      this.updatedUser.address.city = this.city?.value
      if (this.selectedUser.address.city != this.updatedUser.address.city) {
        this.setChangedList('city', this.selectedUser.address.city, this.updatedUser.address.city)
      }
    })

    this.form.controls.postalCode.valueChanges.subscribe(() => {
      this.updatedUser.address.zipcode = this.postalCode?.value
      if (this.selectedUser.address.zipcode != this.updatedUser.address.zipcode) {
        this.setChangedList('postal Code', this.selectedUser.address.zipcode, this.updatedUser.address.zipcode)
      }
    })
  }

  private setChangedList(field: string, prev: string, curr: string) {
    const index = this.changesList.findIndex(x => { return x.field === field })
    if (index >= 0)
      this.changesList[index].modifiedValue = curr
    else
      this.changesList.push({ field: field, previousValue: prev, modifiedValue: curr })

  }

  get name() {
    return this.form.get('name');
  }
  get username() {
    return this.form.get('username');
  }
  get email() {
    return this.form.get('email');
  }
  get unitNo() {
    return this.form.get('unitNo');
  }
  get street() {
    return this.form.get('street');
  }
  get city() {
    return this.form.get('city');
  }
  get postalCode() {
    return this.form.get('postalCode');
  }

  getEmailErrorMessage(): string {
    const errors = this.email?.errors;
    return errors?.required ? REQUIRED_FIELD_MSG : errors?.pattern ? 'Inavlid email address' : '';
  }

  getNameErrorMessage(): string {
    const errors = this.name?.errors;
    return errors?.required
      ? REQUIRED_FIELD_MSG
      : 'Invalid name';
  }

  getUsernameErrorMessage() {
    const errors = this.username?.errors;
    return errors?.required
      ? REQUIRED_FIELD_MSG
      : 'Invalid username';
  }

  getUnitNoErrorMessage() {
    const errors = this.unitNo?.errors;
    return errors?.required
      ? REQUIRED_FIELD_MSG
      : 'Invalid unit no';
  }

  getStreetErrorMessage() {
    const errors = this.street?.errors;
    return errors?.required
      ? REQUIRED_FIELD_MSG
      : 'Invalid street number';
  }

  rebuildForm(): void {
    this.form.reset({
      name: this.selectedUser.name,
      username: this.selectedUser.username,
      email: this.selectedUser.email,
      unitNo: this.selectedUser.address.suite,
      street: this.selectedUser.address.street,
      city: this.selectedUser.address.city,
      postalCode: this.selectedUser.address.zipcode
    })
  }

  private createForm(): FormGroup {
    const form = this.fb.group(
      {
        name: [
          this.selectedUser?.name,
          [Validators.required, Validators.maxLength(20), Validators.pattern("^[A-Za-z]+([-'\\s][A-Za-z]*)*$")],
        ],
        username: [
          this.selectedUser?.username,
          [Validators.required, Validators.maxLength(20), Validators.pattern("^[A-Za-z]+([-'\\s][A-Za-z]*)*$")],
        ],
        email: [
          this.selectedUser?.email,
          [
            Validators.required,
            Validators.pattern('^[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)((\\.[A-Za-z]{2,}){0,1})\\s*$'),
          ],
        ],
        unitNo: [
          this.selectedUser?.address?.suite,
          [Validators.required, Validators.maxLength(20)],
        ],
        street: [
          this.selectedUser?.address?.street,
          [Validators.required, Validators.maxLength(20)],
        ],
        city: [
          this.selectedUser?.address?.city,
          [Validators.required, Validators.maxLength(20)],
        ],
        postalCode: [
          this.selectedUser?.address?.zipcode,
          [Validators.required, Validators.maxLength(20),],
        ],
      },
    );

    return form;
  }
  patternValidator(arg0: RegExp, arg1: { hasLength: boolean; }): any {
    throw new Error('Method not implemented.');
  }
  onSaveClicked() {
    this.isSave = true
  }
  onUpdate() {
    console.log(this.updatedUser)
    this.store.dispatch(dataTableActions.updateData({ data: this.updatedUser }));
    this.router.navigate([''])

  }

  onCancel() { this.router.navigate(['']) }


}
