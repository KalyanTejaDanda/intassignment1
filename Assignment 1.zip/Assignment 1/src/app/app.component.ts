import { Component, OnInit } from '@angular/core';
import { DataService } from './services/data.service';

// RxJs
import { first, map } from 'rxjs/operators';
import { DataTableState, User } from './models/data-table';
import { Store } from '@ngrx/store';

import * as dataTableActions from 'src/app/@ngrx/data-table/data-table.actions';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  

  constructor(private dataService: DataService,private store: Store<DataTableState>,) {}

  ngOnInit() {
    this.dataService.getData().pipe(first(), map((user:User[])=>{
     // DISPATCH
     this.store.dispatch(dataTableActions.setData({ data: user }));
   })).subscribe()
 
  }
}
